export class Aeropuerto {}
