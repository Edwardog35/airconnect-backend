export class CreateAeropuertoDto {}
